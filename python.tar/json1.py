main="/var/tmp/json1.json"
with open(main) as json_data:
    data=json.load(json_data)
    statusflag=




json_output=json_output.decode("utf-8")
buidon_status = json.loads(json_output)
statusflag = format(buidon_status['result'][0]['number'])
print statusflag

