import time
timestr = time.strftime("%Y%m%d-%H%M%S")
print timestr
