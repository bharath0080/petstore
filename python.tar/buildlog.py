from __future__ import print_function
import os
import sys
import re
import time
import commands
import subprocess
import urllib2
branch = "a49beed"
#data = """'{ "buildonid": "%s" }'""" % branch
#url = 'http://10.0.0.94:5000/buildlog -d'
#req = urllib2.Request(url, data, {'Content-Type': 'application/json'})
#f = urllib2.urlopen(req)
#for x in f:
 #   print(x)
#f.close()
print (branch)
cmd = """curl -X POST http://10.0.0.94:5000/buildlog -d '{"buildonid": "%s" }' -H \"Content-Type: application/json\"""" % branch
print (cmd)
buildop = commands.getoutput(cmd)
#buildop=subprocess.check_output(["curl", "-X", "POST", "http://10.0.0.94:5000/buildlog", "-d", "\'{ \"buildonid\": "+branch+" }\'", "-H", "\"Content-Type: application/json\""],stderr=subprocess.PIPE)
log = open ('/var/tmp/buildlog.txt','w')
print(buildop)
