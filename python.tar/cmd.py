import subprocess
bharath="buildontrigger.sh"
path="/var/tmp"
p = subprocess.Popen(['ls ' + bharath], shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,cwd=path)
print(p)
print(p.stdout.readlines())
