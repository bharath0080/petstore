import MySQLdb

#for line in open("/var/tmp/result.txt"):
# if "username" in line:
line = "Password lockerd for user:user1, databases:34.211.100.27"
username=line.split(",")[0]
userName=username.split(":")[-1]
print username
print userName
# if "database" in line:
  #database=line.split(":")[-1]
  #print database
  
