#import os
#res = os.system("tr -cd '[:alnum:]' < /dev/urandom | fold -w30 | head -n1")
#print res
import sh
sh.cmd("tr -cd '[:alnum:]' < /dev/urandom | fold -w30 | head -n1")
print(sh.pwd())
