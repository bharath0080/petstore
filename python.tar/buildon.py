#!/usr/bin/env python

import json
import commands
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import subprocess

statusflag = 'NONE'
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
data= {"commitid": "e2756d2" }
headers={'Content-Type' : 'application/json'}
buildon_status = requests.post('http://34.228.51.230:5000/status',json=data, headers=headers, verify=False )
print buildon_status.content
