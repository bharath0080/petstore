name="bharath kumar"
name=name.replace(" ", "_")
print name
