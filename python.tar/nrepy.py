#!/usr/bin/env python

import json
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import subprocess


def getbuildonstatus(buildonid):
        statusflag = 'NONE'
        while statusflag != 'SUCCESS' or statusflag != 'FAILURE':
            print 'Checking buildon '+buildonid+' status'
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
            data= {"commitid": buildonid}
            headers={'Content-Type' : 'application/json'}
            buildon_status = requests.post('http://34.228.51.230:5000/status',json=data, headers=headers, verify=False )
            json_output=buildon_status.content
            buidon_status = json.loads(json_output)
            statusflag = format(buidon_status['status'])
            print 'Buildon '+buildonid+' status : '+statusflag
            if statusflag == 'SUCCESS' or statusflag == 'FAILURE':
                    break
            time.sleep(15)

getbuildonstatus('e2756d2')
