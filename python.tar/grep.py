import re
line = "Password locked for user:user1, databases:34.211.100.27"
if re.search(r'Password', line) is not None and re.search(r'locked', line) is not None and re.search(r'databases', line) is not None:
    #sys.stdout.write(line)
    print line
