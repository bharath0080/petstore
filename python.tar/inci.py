from SOAPpy import SOAPProxy
import SOAPpy
import json
from jq import jq
import pyjq


username , password , instance  = 'admin' , 'Gtohyd123' , 'dev33395'
proxy , namespace  = 'https://admin:Gtohyd123@dev33395.service-now.com/incident.do?SOAP' , 'https://www.service-now.com/'

server  = SOAPProxy(proxy ,namespace )
response  = server.getRecords()
#response  = server.getRecords(category  = 'network' )
pythonObject = SOAPpy.Types.simplify(response)
jsonObject = json.dumps(pythonObject).decode('utf8')
#jsonObject = json.dumps(pythonObject, ensure_ascii=False).decode('utf8')
numbers = pyjq.all('.',jsonObject)
#numbers = pyjq.all('.[]|.number',jsonObject)
print numbers
