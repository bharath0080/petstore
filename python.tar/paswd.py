import commands
import sys
cmd = 'date +%s | sha256sum | base64 | head -c 32 ; echo'
userpasswd = commands.getoutput(cmd)
sys.stdout = open('/var/tmp/userpasswd.txt', 'w')
print userpasswd 
