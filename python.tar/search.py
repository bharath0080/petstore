import re
import subprocess

test=subprocess.check_output(["git", "remote", "show", "origin"])
#search=re.search(r'Fetch', test)
#print(test)
for item in test.split("\n"):
    if "Fetch" in item:
        splititem = item.strip()
        url=splititem.split(":")[-1]
        finalurl= "https:"+url
        print finalurl
        user=url.split("/")[-2]
        print user

testtttt=subprocess.check_output(["git", "show", "9d572cdd20e1be66d6901cf33fd0e32c5f6753ab"])
#author = testtttt.split('\n', 1)[0]
for itemsa in testtttt.split("\n"):
    if "Author" in itemsa:
        authorname=itemsa.strip()
        finalautor=authorname[authorname.find("<")+1:authorname.find(">")]
        print finalautor
