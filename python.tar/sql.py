#!/usr/bin/python
import MySQLdb

db = MySQLdb.connect(host="34.211.100.27", # your host, usually localhost
                 user="root", # your username
                  passwd="sql123", # your password
                  db="mysql") # name of the data base


cur = db.cursor() 


cur.execute("show tables")
db.commit()
