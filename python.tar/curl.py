import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
headers = {'St2-Api-Key': 'MzY4NzgzNzUwMGEwNzczYTZkMjMyNGE2MDdmZjQ5ZTIzZTMzZTg0NmEyZGUxOGE5NGU2MjM5ZWM5YTI2YzEwOA', 'Content-Type' : 'application/json'}
data = {"user": "bharath0080", "repo": "jpet", "branchname": "test8", "commitID": "cb48d346029473c31f2bef7dd9c2fbc79191c679"}
response = requests.post('https://54.84.2.142/api/v1/webhooks/branches', json=data, headers=headers, verify=False)
print response.status_code

