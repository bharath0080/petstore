import requests
import json

number=10
result = requests.get('https://dev33395.service-now.com/api/now/v1/table/incident', auth=('admin', 'Gtohyd123'))
json_output=result.content
#json_output=json_output.decode("utf-8")	    
#buidon_status = json.loads(json_output)
#statusflag = buidon_status['result']['number']
#statusflag = format(buidon_status['result'][0]['number'])
#print statusflag
if number in json_output:
    print number
